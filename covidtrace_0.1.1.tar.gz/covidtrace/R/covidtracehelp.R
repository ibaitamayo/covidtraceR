
#' covidtrace Package
#'
#' A longer description would go here.
#'
#'
#' @docType package
#'
#' @author julian librero \email{julian.librero@gmail.com}
#'
#' @name covidtrace
