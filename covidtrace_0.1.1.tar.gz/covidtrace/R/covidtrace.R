#' Crear gráfico con la red de contactos de pacientes testados positivos en COVID19
#'
#'@param codare,data,filtrofecha,salida,area codare=Ruta del cmap que por defecto será "D:/R/cmap.Rdata". data=Ruta de la tabla de datos que por defecto será=data = "D:/R/casos_contactos_13_07_2020.xlsx". filtrofecha=Fecha por la que se quiere filtrar, por defecto será 2020-07-05. salida=ruta de salida, por defecto será "D:/Program Files/Tableau/Tableau Server/data/tabsvc/httpd/htdocs/CasosContactos.html",area= string del area, por defecto será "pamplona"
#'@return grafico en html localizado en "salida"
#'@examples
#'covidtracer(codare="F:/Navarrabiomed/Teletrabajo/Dropbox/ju/covid19/Rdata/cmap.Rdata",data = "F:/Navarrabiomed/Teletrabajo/Dropbox/ju/covid19/dat/Gorricho/casos_contactos_13_07_2020.xlsx",salida="CasosContactos.html",area="pamplona")
#'@export
#


mkobj= function(data, filtrofecha=filtrofecha, cipna=cipna, lzbs=zbs, larea=area) {
  require(readr)
  require(dplyr)
  require(lubridate)
  require(epicontacts)
  require(htmlwidgets)



 cc <- read_delim(data,  ";", escape_double = FALSE, trim_ws = TRUE,  locale = locale(encoding = "ISO-8859-1"))

  ## filtro por elementos de los casos [ojo que con el tiempo los contactos son casos..]

 names(cc)[c(2,7,8,25)]= c("cipna",  "lzbs"  ,  "fdia", "larea")
  if(!is.null(filtrofecha)) {cc=cc[cc$fdia>filtrofecha,]}
  if(!is.null(cipna)) {cc=cc[cc$cipna==cipna,]}
  if(!is.null(lzbs)) {cc=cc[cc$lzbs==lzbs,]}
  if(!is.null(larea)) {cc=cc[cc$larea==larea,]}


  cc=cc %>% select(-c(1,6,9,15,16,21)) # quito pacinifcod, uso el literal de zbs y area
  ccca= cc %>% select(1:6,19)
  names(ccca)=c("cipna", "edad", "gen", "cupo", "lzbs"  ,  "fdia","larea")
  ccco= cc%>% select(7:9,11,13:18,20)
  names(ccco)=c("cipna", "edad", "gen","fais","fdia" , "fsin", "cupo","lzbs","ffin", "fpcr_","larea")
  linelist=bind_rows(ccca,ccco)


  linelist=linelist %>% mutate(gen=factor(gen),lzbs=as.factor(lzbs),larea=as.factor(larea),cupo=factor(cupo),fdia=as.Date(fdia), positivo=!is.na(fdia),  )
  linelist=linelist %>% arrange(cipna,-positivo,fais) %>% group_by(cipna) %>% mutate(fdia=min(fdia)) %>% distinct(cipna, .keep_all = TRUE) %>% data.frame()
  linelist=linelist %>% mutate(positivo=factor(positivo, labels = c( "no_confirmado","confirmado")),ecat=cut(edad, breaks = c(0,15,25,35,60,75,110)))

  # anonimizado
  contact=cc %>% select(1,7,10,12)
  names(contact)=c("from", "to", "fuc","exposure")
  contact=contact %>% mutate(from=factor(from), to=factor(to),fuc=as.Date(fuc), exposure=factor(exposure))

  ccce <- make_epicontacts(linelist = linelist,
                           contacts = contact,
                           id="cipna",
                           directed = FALSE)


  vis_epicontacts(ccce, node_color = "ecat",node_shape="positivo", shapes=c(confirmado="exclamation-circle", no_confirmado="exclamation-triangle"), edge_label="exposure", legend = TRUE)

}


covidtracer<-function(data = "D:/R/casos_contactos_13_07_2020.xlsx",filtrofecha=NULL,salida="D:/Program Files/Tableau/Tableau Server/data/tabsvc/httpd/htdocs/CasosContactos.html",cipna=NULL, zbs=NULL, area=NULL){
  require(htmlwidgets)
  enlis=mkobj(data,filtrofecha,cipna,zbs,area)
  return(htmlwidgets::saveWidget(enlis,file=salida))
}

