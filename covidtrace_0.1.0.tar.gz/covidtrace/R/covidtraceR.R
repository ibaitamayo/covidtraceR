#' CovidtraceR Package
#'
#' Contains functions for generating html of contacts
#' @docType package
#' @author SNS-O \email{julian.librero@gmail.com}
#'
#' @name covidtraceR
NULL
